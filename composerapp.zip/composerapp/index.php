<?php
require_once "vendor/autoload.php";
use MicrosoftAzure\Storage\Blob\BlobRestProxy;
use MicrosoftAzure\Storage\Blob\Models\ListBlobsOptions;


$connectionString = "DefaultEndpointsProtocol=https;AccountName=tenmediastore;AccountKey=SifAuxDA7slvSFRsvn3ewSMiRimplA5FEqIqlY1rxaO/ys5pVA2786otT3jT2OOztvxhBlaQg9m8wXGWrkm3DA==;EndpointSuffix=core.windows.net";

// Create a blob client.
$blobClient = BlobRestProxy::createBlobService($connectionString);

// List blobs
$listBlobsOptions = new listBlobsOptions();
$containerName = "userdata-fincsj-amberamouricloudcom";
$fileToStream = "0800fc577294c34e0b28ad2839435945.mp4";

do{
            $result = $blobClient->listBlobs($containerName, $listBlobsOptions);
            foreach ($result->getBlobs() as $blob)
            $listBlobsOptions->setContinuationToken($result->getContinuationToken());
        } while($result->getContinuationToken());


        // Get blob.
        header("Content-Type: video/mp4");
        $blob = $blobClient->getBlob($containerName, $fileToStream);
        fpassthru($blob->getContentStream());






?>
